<h2 class="text-center">Please pick a Category</h2>
<div class="category-btn-wrap">
    <a class="make-trade-link make-trade-link--plan" href="/make-trade-plan">Make a Trade Plan</a>
    <a class="make-trade-link make-trade-link--recap" href="/make-trade-recap">Make a Trade Recap</a>
</div>